package com.sabrien.project2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

public class Register extends AppCompatActivity {

    FirebaseAuth mFirebaseAuth;
    ImageView userImg;
    Uri uri;
    EditText userName;
    EditText password;
    EditText email;
    EditText confiremPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        userImg=findViewById(R.id.userImg);
        mFirebaseAuth = FirebaseAuth.getInstance();
        userName = findViewById(R.id.userName);
        password = findViewById(R.id.PassW);
        confiremPassword = findViewById(R.id.confirmPassword);
        email = findViewById(R.id.email);

    }
    public void Registeration2(View view) {
            if(checkEmailAndPassword()){
                mFirebaseAuth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString()).addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                                if(!task.isSuccessful()){
                                    Toast.makeText(Register.this , "Un unsuccessful registration pleas try again",Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    Intent intent;
                                    intent = new Intent(Register.this, HomeActvity.class);
                                    startActivity(intent);
                                }
                    }
                });
            }
            else{
                Toast.makeText(this , "Error check the data you have given" , Toast.LENGTH_SHORT).show();
            }


    }

    private boolean checkEmailAndPassword() {
        if(!isEmptyEditText(email) && !isEmptyEditText(userName) && !isEmptyEditText(confiremPassword) && !isEmptyEditText(password) && confiremPassword.getText().toString().equals(password.getText().toString()) ){
            return true;
        }
        return false;
    }

    boolean isEmptyEditText(EditText editText){
        if(editText.getText().toString().equals(""))
            return true;
        return false;
    }

    public void AddUserImg(View view) {
        Intent gallery_intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery_intent,100);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100&&resultCode== RESULT_OK)
        {
            uri = data.getData();
            Picasso.with(this).load(uri).into(userImg);

          /*  Uri uri=data.getData();
            userImg.setImageURI(uri);*/
        }
    }
}
