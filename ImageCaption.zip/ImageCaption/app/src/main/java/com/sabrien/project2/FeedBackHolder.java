package com.sabrien.project2;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FeedBackHolder extends RecyclerView.ViewHolder {

    ImageView user_imageView;
    TextView feedback_txt,user_txt;

    public FeedBackHolder(@NonNull View itemView) {
        super(itemView);
        user_txt=itemView.findViewById(R.id.userName_txtV);
        feedback_txt=itemView.findViewById(R.id.feedback_txt);
        user_imageView=itemView.findViewById(R.id.userImg);
    }
}
