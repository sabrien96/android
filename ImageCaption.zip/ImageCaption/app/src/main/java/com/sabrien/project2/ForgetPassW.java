package com.sabrien.project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;

public class ForgetPassW extends AppCompatActivity {

    EditText email;
    Button btn;
    FirebaseAuth mFirebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_pass_w);
        btn=findViewById(R.id.button);
        email = findViewById(R.id.email);
        mFirebaseAuth = FirebaseAuth.getInstance();
    }

    public void EmailSendToGetPasswordClick(View view) {
        if(!email.getText().toString().equals("")){
            mFirebaseAuth.sendPasswordResetEmail(email.getText().toString()).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                        Toast.makeText(ForgetPassW.this , "Reset Message sent to your email address" ,Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(ForgetPassW.this , "Error not sent " +e.getMessage()  ,Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
