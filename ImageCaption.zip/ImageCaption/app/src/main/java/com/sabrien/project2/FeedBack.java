package com.sabrien.project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FeedBack extends AppCompatActivity {

    RecyclerView feedback_List_recycler;
    Button send_btn;
    EditText comment_txt;
    FeedBackAdapter feedBackAdapter;
    ArrayList<Users> UserList;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);
        reference = FirebaseDatabase.getInstance().getReference();
        feedback_List_recycler=findViewById(R.id.feedback_List);
        send_btn=findViewById(R.id.send_btn);
        comment_txt=findViewById(R.id.comment_txt);
        feedBackAdapter = new FeedBackAdapter(UserList);
        UserList=new ArrayList<Users>();
        feedback_List_recycler.setAdapter(feedBackAdapter);
        feedback_List_recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true));
        AddComment();
        RecyclerView.ItemAnimator itemAnimator = new DefaultItemAnimator();
        itemAnimator.setAddDuration(1000);
        itemAnimator.setRemoveDuration(1000);
        feedback_List_recycler.setItemAnimator(itemAnimator);

        reference.child("user").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dt: dataSnapshot.getChildren()) {
                    String userName = dt.child("name").getValue().toString();
                    String comment = dt.child("feedback").getValue().toString();
                    UserList.add(new Users(userName , "non" , comment));
                }
                feedBackAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String comment=comment_txt.getText().toString();
                if(!comment.isEmpty())
                {
                    try
                    {
                        String userName = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                        Log.d("AppDebugSpace" , "reached");
                        Log.d("AppDebugSpace" , userName);
                        UserList.add(new Users(userName ,"non" , comment));
                        comment_txt.setText("");
                        String newId = reference.child("user").push().getKey();
                        Log.d("AppDebugSpace" , newId);
                        reference.child("user").child(newId).child("feedback").setValue(comment);
                        reference.child("user").child(newId).child("name").setValue(userName);
                    }
                    catch (Exception e)
                    {
                        Log.d("AppDebugSpace" , e.getMessage());
                        Toast.makeText(FeedBack.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                else
                    Toast.makeText(FeedBack.this, "can't send empty text", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void AddComment()
    {
       feedBackAdapter = new FeedBackAdapter(UserList);
       feedback_List_recycler.setAdapter(feedBackAdapter);
       feedBackAdapter.notifyDataSetChanged();
    }
}
