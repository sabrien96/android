package com.sabrien.project2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.Loader;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.xml.transform.Result;

public class HomeActvity extends AppCompatActivity {

    boolean busyFlag = false;
    Uri uri;
    ImageView img;
    Button gallery_btn,camera_btn;
    TextView descrptipn_txtV;
    ActionBar actionBar;
    static Socket s = null;
    static DataInputStream DIS = null;
    static ObjectOutputStream oos = null;
    Bitmap currentBitMap = null;
    public static String SERVER_LINK = "link";
    public static String PORT_NUMBER = "port";
    private static final String server_address = "0.tcp.ngrok.io";
    private static final int port_number = 15314;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_actvity);
        MainActivity.indicator = 1;
       camera_btn=findViewById(R.id.camera_btn);
        gallery_btn=findViewById(R.id.gallery_btn);
        img=findViewById(R.id.img);
        descrptipn_txtV=findViewById(R.id.description_txt);
        AsyncTaskInit init = new AsyncTaskInit();
        init.execute();

    }

    /*********************           Menu     *********************** */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent intent;
        if (id == R.id.home) {
            //intent = new Intent(this,HomeActvity.class);
            //startActivity(intent);
        }
        else if (id == R.id.feedback) {
            intent = new Intent(this, FeedBack.class);
            startActivity(intent);
        }
        else if (id == R.id.logout) {
            FirebaseAuth.getInstance().signOut();
            intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            finish();
        }


        return true;
    }
/********************* Camera onclick *******************/
    public void FromCamera(View view) {
        Intent gallery_intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(gallery_intent,100);
    }
   /* @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100&&resultCode== RESULT_OK)
        {
            Uri uri=data.getData();
            img.setImageBitmap((Bitmap) data.getExtras().get("data"));
        }
    }*/


    /********************* Gallery onclick *******************/

    public void FromGallery(View view) {
        Intent gallery_intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery_intent,100);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100&&resultCode== RESULT_OK)
        {
            uri= data.getData();
            Picasso.with(this).load(uri).into(img);
           /* Uri uri=data.getData();

            img.setImageURI(uri);*/
          //
            descrptipn_txtV.setText("");
        }
    }

    /********************* Description  onclick *******************/

    public void DescripImage(View view) {
        if(img.getDrawable() != null) {
            if(!busyFlag) {
                currentBitMap = ((BitmapDrawable) img.getDrawable()).getBitmap();
                descrptipn_txtV.setText("Image 1");
                Toast.makeText(this, getString(R.string.Description), Toast.LENGTH_SHORT).show();
                descrptipn_txtV.setText("Loading ...");
                AsyncTaskRunner runner = new AsyncTaskRunner();
                busyFlag = true;
                runner.execute();
                AsyncTaskRespons responsee = new AsyncTaskRespons();
                responsee.execute();
            }
            else{
                Toast.makeText(this , "the brevios image still processing" , Toast.LENGTH_SHORT).show();
            }
        }
    }


    private class AsyncTaskInit extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            if(s == null) {
                try {
                    s = new Socket("0.tcp.ngrok.io", port_number);
                    DIS = new DataInputStream(s.getInputStream());
                    oos = new ObjectOutputStream(s.getOutputStream());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }
    private  class AsyncTaskRespons extends  AsyncTask<String , String ,String>{

        String serverRespond;

        @Override
        protected String doInBackground(String... strings) {
            try {
                serverRespond = DIS.readUTF();
            }catch (Exception e){
                e.printStackTrace();
            }
            busyFlag = false;
            return serverRespond;
        }

        @Override
        protected void onPostExecute(String s) {
            descrptipn_txtV.setText(s);
        }
    }

    private  class AsyncTaskRunner extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                //Bitmap bitmap = ((BitmapDrawable)img.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                currentBitMap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageInByte = baos.toByteArray();
                baos.close();
                oos.writeObject(imageInByte);

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}

