package com.sabrien.project2;

public class Users {
    public Users(String username, String img, String comment) {
        this.username = username;
        this.img = img;
        this.comment = comment;
    }

    public Users() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    private String username;
    private String img;
    private String comment;
}
