package com.sabrien.project2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    public static int indicator = 0;
   TextView forgetPW;
    EditText Email,Passw;
    Button btnlogin,btnRegister;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        forgetPW=findViewById(R.id.forgetPW);
        btnlogin=findViewById(R.id.btn_login);
        btnRegister=findViewById(R.id.btn_Register);
        Email=findViewById(R.id.mail);
        Passw=findViewById(R.id.Passw);
            mFirebaseAuth = FirebaseAuth.getInstance();

        forgetPW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,ForgetPassW.class);
                startActivity(intent);
            }
        });

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if(mFirebaseUser != null){
                        Toast.makeText(MainActivity.this , "You are logged in " , Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, HomeActvity.class);
                        startActivity(intent);
                    finish();

                }
                else{
                    Toast.makeText(MainActivity.this , "Please log in " , Toast.LENGTH_SHORT).show();
                }
            }
        };

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkEmailAndPassword()){
                    mFirebaseAuth.signInWithEmailAndPassword(Email.getText().toString() , Passw.getText().toString()).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(MainActivity.this , "Log in error try again" , Toast.LENGTH_SHORT).show();
                            }
                            else{

                            }
                        }
                    });
                }
                else{
                    Toast.makeText(MainActivity.this , "Error check the data you have given" , Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private boolean checkEmailAndPassword() {
        if(!isEmptyEditText(Email) && !isEmptyEditText(Passw) ){
            return true;
        }
        return false;
    }
    boolean isEmptyEditText(EditText editText){
        if(editText.getText().toString().equals(""))
            return true;
        return false;
    }
    public void Registeration(View view) {
        try {
            Intent intent;
                intent = new Intent(this, Register.class);
                startActivity(intent);

        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        //if(mAuthStateListener != null)
            mFirebaseAuth.addAuthStateListener(mAuthStateListener);
    }

    public void forgetPasswordClick(View view) {
    }
}
