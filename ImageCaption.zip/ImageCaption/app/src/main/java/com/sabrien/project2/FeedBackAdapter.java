package com.sabrien.project2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FeedBackAdapter extends RecyclerView.Adapter<FeedBackHolder> {

    ArrayList<Users> UserList=new ArrayList<>();
    public FeedBackAdapter(ArrayList<Users> userList) {
        this.UserList=userList;
    }

    @NonNull
    @Override
    public FeedBackHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.feedbackitems, parent, false);
        return new FeedBackHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedBackHolder holder, int position) {
       holder.feedback_txt.setText(UserList.get(position).getComment());
       holder.user_txt.setText(UserList.get(position).getUsername());
      // holder.user_imageView.setImageResource(R.drawable.ic_person_add_black_24dp);
       // Picasso.with(FeedBack.Con).load(R.drawable.ic_person_add_black_24dp).into(holder.user_imageView);



    }

    @Override
    public int getItemCount() {
        return UserList.size();
    }

}
